<?php

$keyId = 'rzp_test_rXRxDyhcd4gC4h';
$keySecret = 'DMiOJdh8qcuJjXD9fIezoxvw';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
